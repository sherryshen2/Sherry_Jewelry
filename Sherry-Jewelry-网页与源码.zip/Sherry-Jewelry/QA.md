# Sherry Jewelry 验收记录

日期：2026-10-24（Asia/Shanghai）。环境：本机 Codex 内置浏览器，1440 × 900 桌面视口及 360 × 800 窄屏视口。不是物理手机测试。

## 初版通过的检查（修改前记录）

| 检查 | 结果与证据 |
|---|---|
| 首页 | 品牌、衬线字体、浅粉底、透明 3D 店面及 Explore；`qa/desktop-home.jpg`、`qa/mobile-home.jpg` |
| 两种入口 | Explore 按钮与店面键盘入口都进入同一主展台 |
| 展台 | 四件商品均加载、挂载各自节点；`qa/desktop-display.jpg`、`qa/mobile-display.jpg` |
| 四款详情 | J001–J004 均加载且标题与模型对应；项链完整与吊坠近景、成对耳环、手链扣件均可见 |
| 实拍 | 配置对应 J001 正面、J002 细节、J003 内圈细节、J004 侧面；完整画面 contain |
| 手机选择 | 缩略图首次点按预览、再次点按打开；`qa/mobile-preview.jpg` |
| 缩放边界 | 反复放大停在 2.5 倍，缩小停在 0.75 倍，复位回 1 倍；`qa/zoom-keyboard.json` |
| 键盘 | 方向键操作、Esc 关闭；修复首次检查发现的 Shift+Tab 焦点离开问题，复测为 Close → Shift+Tab → Buy Now → Tab → Close |
| 历史 | 商品层后退关闭；前进恢复对应商品；展台返回首页 |
| 连续操作 | 四件轮换打开、缩放、关闭，共 20 次；全部标题正确、缩放响应、缓存四款、浏览器错误日志为空；`qa/repeat-20.json` |
| 模型失败 | 测试服务器为全部 GLB 返回 503；首页保留 Explore、展台保留照片列表、详情保留正确照片、Retry 3D、Close、Buy Now；`qa/model-failure.jpg` |
| 购买映射 | 四条 URL 与 PRD 18.2 原样逐字一致，含所有查询参数；不同商品分别映射 Sheet1 B2–B5 |
| 语法与资源 | 两个 JS 模块语法检查通过；所有配置资源存在；十个 GLB 均含 Meshopt 压缩扩展 |

## 资源实测

按文件字节数（MB = 1,000,000 字节），不等同于浏览器实际传输、GPU 内存或帧率：

| 资源 | 原始 | 网页版 |
|---|---:|---:|
| 店面 | 12.51 MB | 4.79 MB |
| 主展台与四件陈列 | 16.10 MB | 4.74 MB |
| J001 详情 | 4.60 MB | 1.02 MB |
| J002 详情 | 1.59 MB | 0.44 MB |
| J003 详情 | 1.57 MB | 0.50 MB |
| J004 详情 | 4.20 MB | 1.12 MB |

通过去重、纹理编码与 Meshopt 几何量化压缩，保留模型版本和陈列姿态。压缩并未以降低面数为目标，真实手机 GPU 性能仍需测量。首页预览由本次网页的透明背景实际渲染生成。

## 尚未完成的外部验收

- 实际 iPhone、Android 中端手机、Safari 与微信内置浏览器的手势、返回和性能记录。
- 冷缓存 10 Mbps / 100 ms RTT 条件下的加载时间、持续 60/30 FPS、图形上下文恢复的实机验证。
- 真实双指手势、减少动态效果系统设置及购买跳转后的系统回收恢复测试。代码分支已实现，未将未执行的测试标记为通过。
- Shopee 四个目的页面的实时 SKU、可达性、价格与库存。检索工具未能访问页面；本站不会声称成交成功。
- 模型与实物的最终销售外观确认；未确认尺寸、材质不在页面作为销售事实展示。

这些边界不影响已完成的本地浏览链路，但正式面向顾客上线前应完成相应验收。

## 交付状态

本地标准版、单文件离线网页和源码归档已同步；网页也已按后续要求部署到 Hangar。单文件已通过脚本语法和本机 HTTP 预览的首屏及商品列表检查；内置浏览器禁止 file 协议，未进行直接打开文件的运行验证。

## 第一版修改验收 · 2026-10-24

在 1440 × 900 和 360 × 800 视口检查了本次修改：

- 首页改为与展台一致的 #F4EDE3 米色，The collection 在右上角；指定首屏小字已移除。
- 星星位于页脚品牌与斜体标语之间，手机布局不重叠。
- 主展区指定文案、Reset View、All Jewelry、Browse photos 均移除；3D 商品与手机缩略图入口保留。
- The collection 四款均加载对应高清实拍；桌面四列、手机两列，图片完整显示。
- 实拍列表打开戒指详情、关闭详情、关闭列表、返回首页均正常；浏览器错误日志为空。
- 源码模块与更新后的离线引导脚本通过语法检查。离线单文件未在浏览器执行，验证范围与交付状态说明一致。

截图：`qa/revision-1/desktop-home.jpg`、`desktop-display.jpg`、`desktop-collection.jpg`、`mobile-home.jpg`、`mobile-display.jpg`、`mobile-collection.jpg`。

## 第二轮修改验收 · 2026-10-24

- 1440 × 900 首页截图确认文字与模型靠近，模型放大且完整；360 × 800 首页正常。
- The collection 四款照片和标题正常，Discover the piece 已删除；手机展台预览卡片只保留图片和商品名，View piece 已删除。
- 浏览器错误日志为空。截图位于 `qa/revision-2/`。
- `tooling/check-hero-motion.mjs` 对实际动画代码作隔离测试（模拟渲染器和命中检测）：采样总位移 16.9997 px，周期 5500 ms；左右跟随、离开回位、拖动角度边界、拖动暂停浮动、减少动态效果均通过。当前浏览器工具无鼠标悬浮移动接口，因此没有将真实鼠标悬浮端到端验证标记为通过。
- app.js、engines.js 与重新生成的离线脚本通过语法检查。离线版仍仅进行生成与脚本检查，浏览器截图来自同源本地 HTTP 版本。

## 第三轮修改验收 · 2026-10-24

本次仅调整首屏运动参数，沿用第二轮布局。实际动画代码的隔离检查测得上下总位移 11.9998 px、周期 5500 ms；跟随在 200 ms 内达到目标的 88% 以上，左右两侧均达到约 15°，与拖动范围一致。拖动暂停浮动、移开回位及减少动态效果检查通过。源码与离线脚本语法检查通过。没有重新执行浏览器鼠标悬浮端到端验收。

## 第四轮修改验收 · 2026-10-24

在 1440 × 900、768 × 900、360 × 800 视口检查首屏。PC 标题单行且不与模型重叠；手机内容整体下移，页脚仍在首屏内。浏览器错误日志为空。截图位于 `qa/revision-4/`。仅调整 CSS，未改变动画和交互逻辑；离线脚本语法与归档完整性检查通过。

## 第五轮修改验收 · 2026-10-24

在 1440 × 900、360 × 800 检查副标题均为单行。桌面从 The collection 打开戒指，手机从主展区打开项链，均捕捉到清晰的金色光点和星芒。手机放大按钮和关闭流程正常，浏览器错误日志为空。截图位于 `qa/revision-5/`，其中 `gold-particles-3.jpg` 与 `mobile-gold-particles.jpg` 为入场效果。app.js 和重新生成的离线引导脚本语法检查通过。浏览器验收使用本机 HTTP 版本。

## 第六轮修改验收 · 2026-10-24

1440 × 900 预览中确认米黄色粒子可见，旋转和缩放提示语不再显示；切换照片再回到 3D 后仍保持隐藏。浏览器错误日志为空。截图：`qa/revision-6/cream-particles.jpg`。app.js 和离线引导脚本语法检查通过。

## 第七轮修改验收 · 2026-10-24

移除照片说明节点及其模式切换引用，确认源码无遗留引用。app.js 与重新生成的离线脚本通过语法检查，归档完整性检查通过。本次为单句文案移除，未重复浏览器验收。


## Progressive startup — 2026-10-24

- The 31,880-byte boutique WebP is preloaded and remains visible until the first complete 3D render. Hangar's outer shell also shows the static home while the embedded storefront initializes.
- The storefront stylesheet is inlined in the uploaded HTML. Three.js starts after poster decode, two animation frames, a 600 ms grace period and a bounded idle callback. Collection models are loaded only on entry; hidden list photos are lazy-loaded.
- Local normal-mode browser observation: static ready at 119 ms; hero initialization at 725 ms; 3D ready at 996 ms. Resource logs showed cached media (304), so these are warm local observations, not a cold network benchmark. No collection canvas or model downloads before navigation.
- Direct Hangar storefront observation: static ready at 747 ms; hero initialization at 1,356 ms; 3D ready at 3,104 ms. Existing browser media cache was retained. These times begin at the embedded storefront navigation, excluding the outer Hangar sign-in/shell.
- Intentional model HTTP 503: boutique image stays visible, retry appears, no orphan hero canvas remains, and Explore opens the collection photo fallback.
- Hangar storefront: collection dialog, necklace detail/photo-to-3D transition, and purchase-link destination checked; no browser errors or warnings. Existing hero motion assertions pass, including drag, hover and reduced motion.
- Hangar source check passes. Publication job reached ready. Fresh token-to-session verification of the canonical app URL reports shell and health OK; the CLI's automatic verification candidate had a different origin and was rejected, so the documented canonical URL was verified explicitly. Fresh published page loads the new asset and opens the collection.
- Remaining measurement gap: no controlled same-network cold-cache before/after benchmark or other-computer timing. Platform startup, authentication and user network still contribute to first-open latency.

## 本地交付同步 · 2026-10-24

- `dist/` 保留与 Hangar 相同的静态图优先、延后加载 3D、商品场景按需加载逻辑。
- 重新生成上一级 `index.html`，打包器先输出静态首屏，并改为用到资源时才解码模型；移除单文件中无效的相对路径预加载。
- 单文件引导脚本语法检查通过。本机 HTTP 预览中静态首屏、3D 渐入、The collection 商品列表正常；首页尚未创建商品展台，浏览器错误和警告日志为空。没有把这些结果作为 file 协议或限速网络测试。
- 更新 `asset-manifest.json`、本说明和 README；重打 `Sherry-Jewelry-网页与源码.zip`，逐文件核对归档内容及校验值。
- 从 Hangar 重新导出 `hangar-jewelry-shop-export.zip`，其中四个应用源文件与本地工作副本逐字节一致；本地应用名称和设置也已与导出元数据同步。
